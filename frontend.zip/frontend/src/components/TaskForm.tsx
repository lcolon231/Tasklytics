// src/components/TaskForm.tsx
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

interface TaskFormData {
  title: string
  description: string
  dueAtLocal: string  // we'll convert this to ISO on submit
  userEmail: string
}

export const TaskForm: React.FC = () => {
  const [form, setForm] = useState<TaskFormData>({
    title: '',
    description: '',
    dueAtLocal: '',
    userEmail: '',
  })
  const navigate = useNavigate()

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target
    setForm(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Convert local datetime to ISO string for the API
    const due_at = new Date(form.dueAtLocal).toISOString()

    try {
      const res = await fetch('http://127.0.0.1:8000/tasks/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: form.title,
          description: form.description,
          due_at,
          user_email: form.userEmail,
        }),
      })

      if (!res.ok) {
        const text = await res.text()
        console.error('Failed to create task:', text)
        alert('Error creating task. Check console for details.')
        return
      }

      // on success, go back to the list
      navigate('/')
    } catch (err) {
      console.error(err)
      alert('Network error creating task')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="task-form">
      <div>
        <label>
          Title
          <input
            name="title"
            value={form.title}
            onChange={handleChange}
            required
          />
        </label>
      </div>

      <div>
        <label>
          Description
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
          />
        </label>
      </div>

      <div>
        <label>
          Due at
          <input
            type="datetime-local"
            name="dueAtLocal"
            value={form.dueAtLocal}
            onChange={handleChange}
            required
          />
        </label>
      </div>

      <div>
        <label>
          Your Email
          <input
            type="email"
            name="userEmail"
            value={form.userEmail}
            onChange={handleChange}
            required
          />
        </label>
      </div>

      <button type="submit">Create Task</button>
    </form>
  )
}
