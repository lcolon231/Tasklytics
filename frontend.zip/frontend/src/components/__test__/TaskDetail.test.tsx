// src/components/__test__/TaskDetail.test.tsx

// 🛑 Mock BEFORE you import React or your component
import { vi, describe, it, expect, beforeAll, afterAll } from 'vitest'

// 1️⃣ Must mock the real ../api before TaskDetail imports it
vi.mock('../../api', () => ({
  getTask: vi.fn().mockResolvedValue({ id: 123, title: 'foo', description: 'bar' }),
  deleteTask: vi.fn().mockResolvedValue({ detail: 'deleted' }),
}))

// 2️⃣ Pull in the Vitest‑compatible jest‑dom matchers
import '@testing-library/jest-dom/vitest'

import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import { TaskDetail } from '../TaskDetail'

describe('<TaskDetail />', () => {
  let confirmSpy: ReturnType<typeof vi.spyOn>

  beforeAll(() => {
    // Spy window.confirm so delete flow can proceed
    confirmSpy = vi.spyOn(window, 'confirm').mockImplementation(() => true)
  })
  afterAll(() => {
    confirmSpy.mockRestore()
  })

  it('shows details and lets you delete', async () => {
    // grab the mocked fns for assertions
    const { getTask, deleteTask } = await import('../../api')

    render(
      <MemoryRouter initialEntries={['/tasks/123']}>
        <Routes>
          <Route path="/tasks/:id" element={<TaskDetail />} />
        </Routes>
      </MemoryRouter>
    )

    // 3️⃣ Your fake title "foo" should show up
    expect(await screen.findByText('foo')).toBeInTheDocument()

    // 4️⃣ Click Delete…
    fireEvent.click(screen.getByText(/delete/i))

    // 5️⃣ …and confirm() + deleteTask(123) were called
    await waitFor(() => {
      expect(confirmSpy).toHaveBeenCalledWith(
        'Are you sure you want to delete this task?'
      )
      expect(deleteTask).toHaveBeenCalledWith(123)
    })
  })
})
