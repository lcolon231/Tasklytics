// src/components/TaskDetail.tsx
import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { getTask, deleteTask } from '../api'
import type { Task } from '../types'

type Task = {
  id: number
  title: string
  description: string
}

export function TaskDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [task, setTask] = useState<Task | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!id) return
    getTask(Number(id))
      .then((t) => setTask(t))
      .catch(() => setError('fetch failed'))
  }, [id])

  if (error) {
    return (
      <div>
        <p>Error: {error}</p>
      </div>
    )
  }

  if (!task) {
    return <p>Loading...</p>
  }

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      await deleteTask(task.id)
      navigate('/tasks')
    }
  }

  return (
    <div>
      <h1>{task.title}</h1>
      <p>{task.description}</p>
      <button onClick={handleDelete}>Delete</button>
    </div>
  )
}
