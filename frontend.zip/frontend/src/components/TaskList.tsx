import { useEffect, useState } from "react";
import { fetchTasks } from "../api";
import type { Task } from "../types";

export function TaskList() {
  const [tasks, setTasks] = useState<Task[]>([]);
  useEffect(() => {
    fetchTasks().then(setTasks);
  }, []);
  return (
    <div>
      <h2>Your Tasks</h2>
      <ul>
        {tasks.map(t => (
          <li key={t.id}>
            <strong>{t.title}</strong> — due {new Date(t.due_at).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
