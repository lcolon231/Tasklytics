import React from 'react'
import { Routes, Route, Navigate ,Link } from 'react-router-dom'
import { TaskList } from './components/TaskList'
import { TaskDetail } from './components/TaskDetail'
import { TaskForm } from './components/TaskForm'

export default function App() {
  return (
    <div>
      <nav style={{ marginBottom: 20}}>
        <Link to="/tasks">All Tasks</Link>
        <link to="/tasks/new">New Task</link>
      </nav>

      <Routes>
      <Route path="/" element={<Navigate to="/tasks" replace />} />
      <Route path="/tasks" element={<TaskList />} />
      <Route path="/tasks/new" element={<TaskForm />} />
      <Route path="/tasks/:id" element={<TaskDetail />} />
      </Routes>
    </div>
  )
}
