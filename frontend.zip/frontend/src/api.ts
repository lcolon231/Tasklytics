// frontend/src/api.ts
export interface Task {
  id: number
  title: string
  description: string
}

export interface DeleteResponse {
  detail: string
}

// 1️⃣ Fetch the list of tasks
export async function fetchTasks(): Promise<Task[]> {
  const res = await fetch('http://localhost:8000/tasks/')
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  return res.json()
}

// 2️⃣ Fetch one task by ID
export async function getTask(id: number): Promise<Task> {
  const res = await fetch(`http://localhost:8000/tasks/${id}`)
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  return res.json()
}

// 3️⃣ Delete one task by ID
export async function deleteTask(id: number): Promise<DeleteResponse> {
  const res = await fetch(`http://localhost:8000/tasks/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  return res.json()
}
