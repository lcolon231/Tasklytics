import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { TaskList } from './components/TaskList'
import { TaskForm } from './components/TaskForm'
import { TaskDetail } from './components/TaskDetail'
import './index.css'  // if you have global styles
import App from './App'

const root = ReactDOM.createRoot(document.getElementById('root')!)
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode> // ✅ this must be properly closed
)