export interface Task {
  id: number;
  title: string;
  description: string;
  due_at: string;
  user_email: string;
}

export interface DeleteResponse {
  detail: string;
}
