// src/components/TaskList.tsx
import React, { useEffect, useState } from 'react';
import { Task } from '../types';
import { Link } from 'react-router-dom';

const TaskList: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    fetch('http://localhost:8000/tasks/')
      .then(res => res.json())
      .then(setTasks)
      .catch(console.error);
  }, []);

  return (
    <>
      <h2>Your Tasks</h2>
      {tasks.length === 0 ? (
        <p>No tasks yet. Start by creating one.</p>
      ) : (
        <ul>
          {tasks.map(task => (
            <li key={task.id}>
              <Link to={`/tasks/${task.id}`}>
                <strong>{task.title}</strong> — due {new Date(task.due_at).toLocaleString()}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </>
  );
};

export default TaskList;
