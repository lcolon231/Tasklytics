// src/components/NotificationList.tsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Notification {
  id: number;
  message: string;
  created_at: string;
}

const NotificationList: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const res = await axios.get('http://localhost:8000/notifications/');
        console.log('Fetched notifications:', res.data);
        setNotifications(res.data);
      } catch (err) {
        console.error('Error fetching notifications:', err);
      }
    };
    fetchNotifications();
  }, []);

  return (
    <div className="card">
      <h2>🔔 Notifications</h2>
      {notifications.length === 0 ? (
        <p>No notifications available.</p>
      ) : (
        <ul>
          {notifications.map(n => (
            <li key={n.id}>
              {n.message} — <small>{new Date(n.created_at).toLocaleString()}</small>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default NotificationList;
