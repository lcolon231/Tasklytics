// src/App.tsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import NotificationList from './components/NotificationList';
import './App.css';
import Login from './components/Login'

const App: React.FC = () => {
  return (
    <Router>
      <div className="navbar">
        <div className="container">
          <Link to="/" className="logo">Tasklytics</Link>
          <nav>
            <Link to="/">Home</Link>
            <Link to="/new">New Task</Link>
            <Link to="/notifications">Notifications</Link>
            <Link to="/login">Login</Link>
          </nav>
        </div>
      </div>

      <main className="container">
        <Routes>
          <Route path="/" element={<TaskList />} />
          <Route path="/new" element={<TaskForm />} />
          <Route path="/login" element={<Login />} />
          <Route path="/notifications" element={<NotificationList />} />
        </Routes>
      </main>
    </Router>
  );
};

export default App;
